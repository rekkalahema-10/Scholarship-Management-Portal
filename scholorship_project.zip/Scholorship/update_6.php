
<html>
    <head><title>Saibaba</title>
<style>
    body{
        font-family: cursive;
        /*background: linear-gradient(45deg, black,black,50%,gray 25%, gray);*/
        color:black;
        font-size: 25px;
        font-weight: bold;
       
        background: linear-gradient(45deg,white,white);
    

    }
    .card{
            margin-left: 8%;
           width:80%;
           box-shadow: 10px 10px 10px 10px gray;
       
            padding:10px;
       
        }
        .card #form9{
            max-width: 900px;
           

        }
        .card #form9 input{
            width: 50%;
        }
        .card #form9 button{
            width:30%;
           
        }
        .card #form9 button:hover{
            background-color:black;
            color:white;


           
        }
        @media(max-width:991px){
            .card{
           width:100%;
           box-shadow: 10px 10px 10px 10px gray;
            font-size: 17px;
            margin-left: 2px;
        }
    
        }
    </style>
</head>
    <body>
    <div class="card">
    <form method="post" enctype="multipart/form-data" id="form9" onsubmit="return validForm()">
            Name:<input type="text" name="name" style="width:50%">
             ID      :<input type="text" name="id" id="idnum" style="width:30%">
             <div id="nameError" style="color: red;"></div>
             Email   :<input type="email" name="email" style="width:50%" >
             Password:<input type="password" name="password" id="password" style="width:20%"><br><br>
         DOB     :<input type="date" name="dob" style="width:30%">
        Gender  :<select name="select"><option value="Male">Male</option><option value="Female" >Female</option><option value="other">Other</option> </select> 
             Religion:<input type="text" name="Religion" style="width:30%"><br><br>
             Caste   :<input type="text" name="cast" style="width:10%">
             Year    :<input type="text" name="year" style="width:10%">
             Branch  :<input type="text" name="branch" style="width:20%">
             Class   :<input type="text" name="class" style="width:20%"><br><br>
             Mother Name:<input name="mname" type="text" ><br><br>
             Father Name:<input type="text" name="fname"><br><br>
             Guardian Name:<input type="text" name="guard"><br><br>
             Student Mobile:<input type="text" name="smobile" style="width:30%">
             Parent Mobile:<input type="text" name="pmobile" id="mobile" style="width:30%"><br><br>
             <center>Profile:<input type="file" name="profile" style="font-size:20px"><br><br><center>
        <button type="submit" name="btn">Update</button>
</div>
    </form>
    <script>
     $(document).ready(function() {
            $("#form9").submit(function(event) {
                event.preventDefault();
                var formData = new FormData(this);

                $.ajax({
                    type: "POST",
                    url: "welcome_6.php",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        alert(response);
                    }
                });
            });
        });

</script>
<?php
include 'con.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
$id=$_POST['email'];
$sql = "SELECT * FROM `reg1` WHERE username='$id'";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    $alumniDetails = $result->fetch_assoc();

    // Close the database connection
    $con->close();
}}?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <!-- Add this line to include SweetAlert library -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<script>
    function validForm(){
        const mobile=document.getElementById('mobile').value;
        const idnum=document.getElementById('idnum').value;
        if(mobile.length!=10){
            alert("mobile number must be 10 digits");
            return false;
        }
        if(idnum.charAt(0)!='O'){
            document.getElementById('nameError').innerHTML="id Number must start with O";
            return false;
        }
        $('#password').val('<?php echo $alumniDetails['password']; ?>');
               


    }
</script>
    </body>
</html>