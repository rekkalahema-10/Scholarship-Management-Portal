<?php
    include 'con.php';
    if($_SERVER['REQUEST_METHOD']=='POST'){
    $email=$_POST['email'];
    $password=$_POST['password'];
    $sql="select * from `signup` where email='$email'";
    $result=mysqli_query($con,$sql);
    if($result){
        $num=mysqli_num_rows($result);
        if($num>0){
            header('location:signup.php');
          }
        else{
            $sql1="INSERT INTO `signup`  VALUES ('$email', '$password')";
    $result1=mysqli_query($con,$sql1);}
    if($result1){
        header('location:sai1.php');
    }
    else{
        echo "error";
    }
        }  }
?>
<html>
  <head>
    <title>Signup</title>
  </head>
  <body>
    <form method="post">
      Username:<input type="text" name="email" value=""><br>
      Password:<input type="password" name="password" value="" ><br>
      <input type="submit" value="SignUp">
    </form>
  </body>
</html>