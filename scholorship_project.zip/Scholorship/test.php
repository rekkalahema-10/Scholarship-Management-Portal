<?php
/*require('fpdf.php');
$pdf=new FPDF();
$pdf->AddPage();
$pdf->Image("certificate.jpg",0,0,210,150);
$pdf->Output("sai.pdf","F");*/
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;
// Load PHPMailer classes
require "phpmailer/src/SMTP.php";
require "phpmailer/src/PHPMailer.php";
require "phpmailer/src/Exception.php";
include('smtp/PHPMailerAutoload.php');
$mail=new PHPMailer();
$mail->isSMTP();
$mail->Host='smtp.gmail.com';
$mail->Port=587;
$mail->SMTPSecure="tls";
$mail->SMTPAuth=true;
$mail->Username="sailahiri61@gmail.com";
$mail->Password="khuj ihrd emiq xfli";
$mail->setFrom("sailahiri61@gmail.com");
$mail->addAddress("sailahiri61@gmail.com");
$mail->isHTML(true);
$mail->Subject="NO DUE CERTIFICATE";
$mail->Body="Certificate Generated";
$mail->addAttachment("Certificates/1702033018.pdf");
$mail->SMTPOptions=array("ssl"=>array(
    "verify_peer"=>false,
    "verify_peer_name"=>false,
    "allow_self_signed"=>false,
));
if($mail->send()){
    echo "Send";
}else{
    echo $mail->ErrorInfo;
}
?>