<?php
include 'con.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
     $sid=$_POST['id'];
     $desc=$_POST['description'];
    $email=$_POST['email'];
    $sql="insert into `Report` values('$sid','$email','$desc')";
        $result=mysqli_query($con,$sql);
        if($result){
            echo "Report Submitted Successfully";
        }
}
?>