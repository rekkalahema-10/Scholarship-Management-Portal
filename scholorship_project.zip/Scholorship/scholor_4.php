<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    #adminPanel {
      display: flex;
      height: 100vh;
    }

    #sidebar {
      width: 250px;
      background-color:rgb(232, 228, 235);
      color: black;
      padding: 20px;
      box-shadow: 2px 0px 5px rgba(0, 0, 0, 0.1);
    }

    #navbar {
      width: 100%;
      background-color: rgb(64,86,182);
      color: black;
      padding: 20px;
      box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
      display: flex;
  

    }
    #navbar h1{
      margin-left: 30%;
    }
    #sidebar a {
      display: block;
      color: black;
      text-decoration: none;
      margin-bottom: 10px;
    }

    #sidebar a:hover {
      background-color:rgb(64,86,182);
      height:30px;
      color:white;
    }
  </style>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
<div id="navbar">
      <h1>Admin Panel</h1>
    </div>
  <div id="adminPanel">
    <div id="sidebar">
      <a href="#" onclick="loadContent('home')">Home</a>
      <a href="#" onclick="loadContent('users')">Certificate Generation</a>
      <a href="#"  onclick="loadContent('dashboard')">Certificate Applications</a>

      <a href="#" onclick="logout()">Logout</a>
    </div>

   

    <div id="mainContent">
      <!-- Placeholder for main content -->
      <h2>Welcome to the Admin Panel</h2>
     
    </div>
  </div>

  <script>
    function loadContent(page) {
      // For demonstration purposes, load different content based on the selected page
      if (page === 'home') {
        // Display the default home content
        document.getElementById('mainContent').innerHTML = `
          <h2>Welcome to the Admin Panel</h2>
         
        `;
      } else if (page === 'users') {
        loadFile('certificate1.php');
      }
        else if (page === 'dashboard') {
        loadFile('examinor.php');
        
      } 
    }
    function loadFile(fileName) {
      const xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
          document.getElementById('mainContent').innerHTML = this.responseText;
        }
      };
      xhttp.open('GET', fileName, true);
      xhttp.send();
    }

   
    function logout() {
      // Perform logout actions here (e.g., redirect to login page)
     window.location.href="contact.php";
    }
  </script>

</body>
</html>
