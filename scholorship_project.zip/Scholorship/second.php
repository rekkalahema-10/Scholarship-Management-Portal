<?php
include 'con.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    $email=$_POST['email'];
    $_SESSION['email1']=$email;
    $image=$_FILES['file'];
    $imagefilename=$image['name'];
    $imagefiletemp=$image["tmp_name"];
   $id=$_SESSION['id'];
    $filename_seperate=explode('.',$imagefilename);
    $file_extension=strtolower($filename_seperate[1]);
    //print_r($file_extension);
    //echo "<br>";
    $extensions=array('jpeg','jpg','png');
    if(in_array($file_extension,$extensions)){
        $upload_image=$imagefilename;
        move_uploaded_file($imagefiletemp,$upload_image);
        $sql="update `od` set file='$upload_image',Email='$email' where student_id='$id'";
        if ($con->query($sql) === TRUE) {
            echo '<script>alert("Reciept Submitted successfully");</script>';
       
        } }}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form with Select Box, File Upload, and Description</title>

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        h2 {
            text-align: center;
            color: #333;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        select, input[type="file"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        input[type="submit"] {
            background-color: blue;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 18px;
        }

        input[type="submit"]:hover {
            background-color:rgb(64,86,182);
            color:white;
            border:1px solid black;
        }
    </style>
</head>
<body>

    <form  method="post" enctype="multipart/form-data">
        <!-- Select Box -->
        <label for="file">Email</label>
        <input type="email" id="email" name="email" style="height:30px;width:100%">
        <!-- File Upload -->
        <label for="file">Upload No Due Certificate</label>
        <input type="file" id="file" name="file">

        <!-- Description (Text Area) -->
        <label for="description">Description:</label>
        <textarea id="description" name="description" rows="4" cols="50"></textarea>

        <!-- Submit Button -->
        <input type="submit" value="Submit">
    </form>

</body>
</html>
