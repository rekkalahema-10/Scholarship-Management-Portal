// JavaScript for handling interactive
// script.js
document.getElementById('toggle-button').addEventListener('click', function() {
    document.querySelector('.sidebar').classList.toggle('active');
    document.querySelector('.main-content').classList.toggle('active');
});
