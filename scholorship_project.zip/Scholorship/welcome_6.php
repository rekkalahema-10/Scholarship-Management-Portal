<?php 
include 'con.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $id=$_POST['id'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $dob=$_POST['dob'];
    $Religion=$_POST['Religion'];
    $cast=$_POST['cast'];
    $year=$_POST['year'];
    $branch=$_POST['branch'];
    $class=$_POST['class'];
    $role='student';
    $mname=$_POST['mname'];
    $fname=$_POST['fname'];
    $guard=$_POST['guard'];
    $smobile=$_POST['smobile'];
    $pmobile=$_POST['pmobile'];
    $image=$_FILES['profile'];//it is two dimensional associative global array 
    // echo $username;

     //echo $mobile;
     //print_r($image);
     $imagefilename=$image["name"];
     //print_r( $imagefilename);
     //echo "<br>";
     $imagefileerror=$image['error'];
     //print_r(  $imagefileerror);
     //echo "<br>";
     $imagefiletemp=$image["tmp_name"];
     //print_r( $imagefiletemp);
     //echo "<br>";
     $filename_seperate=explode('.',$imagefilename);
     //print_r($filename_seperate);
     //echo "<br>";
     $file_extension=strtolower($filename_seperate[1]);
     //print_r($file_extension);
     //echo "<br>";
     $extensions=array('jpeg','jpg','png');
     if(in_array($file_extension,$extensions)){
         $upload_image=$imagefilename;
         move_uploaded_file($imagefiletemp,$upload_image);
    $sql="update `reg1` set username='$email',password='$password',Role='$role',profile='$upload_image',Name='$name',dob='$dob',Religion='$Religion',year='$year',branch='$branch',class='$class',MotherName='$mname',FatherName='$fname',StudentMobile='$smobile',ParentMobile='$pmobile' where username='$email'";
    $result=mysqli_query($con,$sql);
    if($result){
        echo "success";
    }
}}
?>