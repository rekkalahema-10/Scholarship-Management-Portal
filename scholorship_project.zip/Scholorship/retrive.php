<html>
    <head>
        <title>Image From Database</title>
    </head>
    <body>
    <?php
        include  "con.php";
        $i=0;
        session_start();
        $id=$_POST['id'];
        $_SESSION['id']=$id;
        $sql="select * from `sai` where  `ID`='$id'";
        $result=mysqli_query($con,$sql);
        while($row=mysqli_fetch_assoc($result)){
            $rec=$row['profile_picture'];?>  
             <img src="<?php echo $rec;?>" alt="image not displayed" width="100" height="100"><br>
             <?php }?>
    </body>
</html>
