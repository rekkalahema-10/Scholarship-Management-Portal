  
<?php
include 'con.php';
if($_SERVER['REQUEST_METHOD']=='POST'){
  $image=$_FILES['file'];
    $imagefilename=$image['name'];
    $imagefiletemp=$image["tmp_name"];
    $filename_seperate=explode('.',$imagefilename);
    $file_extension=strtolower($filename_seperate[1]);
    //print_r($file_extension);
    //echo "<br>";
    $extensions=array('jpeg','jpg','png');
    if(in_array($file_extension,$extensions)){
        $upload_image=$imagefilename;
        move_uploaded_file($imagefiletemp,$upload_image);
        $sql="insert into `image` values('$upload_image')";
        $result=mysqli_query($con,$sql);
        if ($result) {
           echo "file uploaded successfully";
       
        }
      }}  
      ?>
  <html>
    <head><title>Upload Image</title></head>
    <body>
      <form method="post" enctype="multipart/form-data">
      Upload Reciept: <input type="file" name="file"><br><br>
      <input type="submit" value="upload">
      </form>
 
    </body>
  </html>

