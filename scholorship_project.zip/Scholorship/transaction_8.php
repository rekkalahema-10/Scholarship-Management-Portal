<html>
    <head>
        <title>Saibaba</title>
        <style>
            /*div{
                width:100%;
                height:50%;
                background-image: linear-gradient(40deg,blue,navy);

            }*/

            .form5{
                background-color: transparent;
                margin-top: 10%;
            } 
            input{
                height:40px;
                background-color:transparent;
                color:black;
                font-size: 20px;
                border:none;
                padding: 2px;
                outline: none;
            }     
            button{
                height: 40px;
                width:20%;
                background-color: black;
                border: none;
            }   
          
        /* Style for the input field */
        .search-input {
            border: none;
            outline: none;
            width: 100%;
            background-color: white;
        }
        .input-container {
            display: flex;
            align-items: center;
            width: 200px; /* Adjust the width as needed */
            border: 1px solid black;
            border-radius: 5px;
            padding: 1px;
            background-color:white;
       
        }
        body{
            background: linear-gradient(45deg,white,white);
            background-image:url('transaction.jpg');
            background-repeat: no-repeat;
            background-position-y: 80px;
            background-position-x: -20%;
         background-color: white;
            background-attachment: fixed;
            background-size: 100% 100%;
        }
        </style>
    </head>
    <body>
    <!--<div><img src="sc.png" height="100%" width="100%"></div>-->
        
    <form method="post" action="transaction_9.php" class="form5"> 
       <center>
       <div class="input-container">
        <input type="text" name="id" placeholder="Enter Id no">
        <button type="submit" name="submit" class="search-input"><span class="search-icon">&#128269;</span></button>
   
        </div>
        </center>
    </form>
      
    </body>
</html>
