
<?php 
include 'con.php';
?>
<!--<html>
    <head><title>Saibaba</title></head>
    <style>
        button{
           width:20%;
           height:50px;
           color:black;
           border-radius: 2px;
           margin-left: 20%;
        }
        body {
   
    font-family: Arial, Helvetica, sans-serif;
   /* Replace 'texture.jpg' with your texture or pattern image */
   
    font-size: 50px;
    font-weight: bold;
}

#registration-form {
   /* White background for the form */
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Optional: Add a subtle shadow */
}
form{
    color:maroon;
    margin-top: 10%;
    font-size: 20px;    
    font-weight:bolder;
}
   
#btn {
            background-color:blue;
            color: #fff;
            margin-top: 10px;
        }
        #btn:hover{
            background-color: white;
            color:blue;
            border:1px solid black;
        }

        .card{
            box-shadow: 10px 10px 10px 10px gray;
         
        }
        input:hover{
            border:4px solid skyblue;
        }
        @media (max-width:858px){
            .form-column input{
                width:50%;
                margin-left:0;
            }
            #btn{
                width:50%;
            }
        }
    </style>
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css"
rel="stylesheet" integrity="sha384-
1BmE4KWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqy12QvZ6jIW3”
crossorigin="anonymous">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>   

    <body>
       <center>
 
        <div id="registration-form" class="card">
     
        <form method="POST" enctype="multipart/form-data" id="form" action="file.php">      
        <div class="form-container row">
        <div class="form-column">
          <pre>
            ScholorshipId:<input type="text" name="sid" id="sid" required><br><br>
            id           :<input type="text" name="id" required><br><br>
            Name         :<input type="text" name="name"><br><br>
            course&year  :<input type="text" name="cy"><br><br> 
            Email        :<input type="email" name="email" ><br><br></pre>

</div>
         <div class="form-column">
         <pre>
            Password     :<input typr="password" name="password" ><br><br>
            JVD/Vasathi  :<input type="text" name="jvd"><br><br>
            Amount       :<input type="text" name="amount"><br><br>
            SBI Reference NO:<input type="text" name="tid" required><br><br>
            Upload Reciept: <input type="file" name="file" required><br><br></pre>
            </div>
            </div>          
<button type="submit" name="submit" class="btn btn-custom btn-lg" role="button" id="btn">Submit</button>
        </form>
        </div>
       </center>
       <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
       <script>
     $(document).ready(function() {
            $("#form").submit(function(event) {
                event.preventDefault();
                var formData = new FormData(this);

                $.ajax({
                    type: "POST",
                    url: "file.php",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        alert(response);
                    }
                });
            });
        });
 

</script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
integrity "sha384-
7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31e0z1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB"
crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
integrity="sha384-
QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13"
crossorigin="anonymous"></script>

</body>
</html>-->
<html>
    <head><title>Saibaba</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script></head>
    <style>
        body {
            font-family: cursive;
            font-size: 25px;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            background: linear-gradient(45deg,white,white);
        }
        header{
            padding: 10px;
        }
        .container1 {
            max-width: 600px;
            background-color:white;
            padding: 20px;
            border-radius: 8px;
            margin-left: 25%;
            margin-top: 0;
            box-shadow: 10px 10px 10px 10px rgb(64,86,182);
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            background-color: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
      
  
        }

         .container1 input{
            width:30%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        #form input[type="file"] {
            margin-bottom: 20px;
        }
        #form label {
            margin-bottom: 8px;
            font-weight: bold;
        }
       a{
        float:right;
       }
       button{
        width: 30%;
        background-color: rgb(64,86,182);

       }
        input:hover {
            border-color: #007BFF; /* Change this to the color you want on hover */
        }
        button:hover {
            background-color: #0056b3;
        }
        label {
      flex: 1;
      margin-right: 10px;
    }
    input, select, textarea {
      flex: 2;
      margin-bottom: 10px;
    }
        @media(max-width:858px){
            .container{
                margin-top: 30%;
            }
        }
    </style>
    <body>
<main>
        <div class="container1"> 
        <form method="POST" enctype="multipart/form-data" id="form" onsubmit="return validateForm()">      
          *ScholorshipId:<input type="text" name="sid" id="sid" required>
            *Id:   <input type="text" name="id">  <br><br>
           Name: <input type="text" name="name" id="name1" style="width:70%" required>
            <div id="nameError" style="color: red;"></div>
            Course&Year: <input type="text" name="cy" style="width:50%"> <br>
            *Email: <input type="email" name="email" id="email" style="width:70%"><br>
           *Password:<input type="password" name="password" id="password" style="width:40%">
           <div id="nameError1" style="color: red;"></div>
           *cast<input type="text" name="cast" placeholder="BC-A,SC,OC,ST" style="width:30%"><br>
           JVD:<input type="text" name="jvd">
            *Amount: <input type="text" name="amount"  style="width:30%"><br><br>
         *SBI Reference NO:<input type="text" name="tid" id="tid" style="width:50%">
         <div id="nameError2" style="color: red;"></div>
            *Upload Reciept: <input type="file" name="file"><br><br>       
<center><button type="submit" name="submit" role="button" >Submit</button></center>
        </form>
        </div>
</main>
<script>
function validateForm() {
      // Get the email input value
      var email = document.getElementById('email').value;
      var password= document.getElementById('password').value;
      var tid= document.getElementById('tid').value;
      var name = document.getElementById('name1');
      var alphaExp = /^[A-Za-z\s]+$/;
      if(email==""){
        alert("Please Fill Required Fields");
        return false;
      }
      if(password.length!=8){
        document.getElementById("nameError1").innerHTML = "password must be at least 8 characters";
      }
       if(!name.value.match(alphaExp)){
        document.getElementById("nameError").innerHTML = "Name must contain alphabets only";
        return false;}
        return true;
  }
</script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
       <script>
     $(document).ready(function() {
            $("#form").submit(function(event) {
                event.preventDefault();
                var formData = new FormData(this);

                $.ajax({
                    type: "POST",
                    url: "file_7.php",
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        alert(response);
                    }
                });
            });
        });
 

</script>
</body>
</html>