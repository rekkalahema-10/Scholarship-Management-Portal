<html>
    <head>
        <title>Saibaba</title>
    </head>
    <body>
    <main>
<div id="arr">
    <button id="button" type="button" onclick="window.location.href='chat.php'">Apply For Certificate</button>
      </div>  </main>   
    </body>
</html>
